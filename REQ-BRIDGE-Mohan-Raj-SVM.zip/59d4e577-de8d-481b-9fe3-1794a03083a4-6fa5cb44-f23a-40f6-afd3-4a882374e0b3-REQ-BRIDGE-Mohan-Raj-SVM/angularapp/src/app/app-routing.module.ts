import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuard } from './components/auth.guard';
import { RegistrationComponent } from './components/registration/registration.component';
import { LoginComponent } from './components/login/login.component';
import { HomeComponent } from './components/home/home.component';
import { ErrorComponent } from './components/error/error.component';
import { AnalystnavComponent } from './components/analystnav/analystnav.component';
import { AnalystHomeComponent } from './components/analyst-home/analyst-home.component';
import { AnalystViewRequirementComponent } from './components/analyst-view-requirement/analyst-view-requirement.component';
import { ManagernavComponent } from './components/managernav/managernav.component';
import { ManagerHomeComponent } from './components/manager-home/manager-home.component';
import { ManagerviewfeedbackComponent } from './components/managerviewfeedback/managerviewfeedback.component';
import { ManagerAddProjectComponent } from './components/manager-add-project/manager-add-project.component';
import { ManagerViewProjectComponent } from './components/manager-view-project/manager-view-project.component';
import { ManagerEditProjectComponent } from './components/manager-edit-project/manager-edit-project.component';
import { ManagerViewRequirementComponent } from './components/manager-view-requirement/manager-view-requirement.component';
import { AnalystaddfeedbackComponent } from './components/analystaddfeedback/analystaddfeedback.component';
import { AnalystViewFeedbackComponent } from './components/analystviewfeedback/analystviewfeedback.component';
import { AnalystAddRequirementComponent } from './components/analyst-add-requirement/analyst-add-requirement.component';
import { AnalystViewProjectComponent } from './components/analyst-view-project/analyst-view-project.component';


const routes: Routes = [

  { path: '', redirectTo: '/home', pathMatch: 'full' },
  { path: 'home', component: HomeComponent },
  { path: 'register', component: RegistrationComponent },
  { path: 'login', component: LoginComponent },
  { path: 'managernav', component: ManagernavComponent, canActivate: [AuthGuard]},
  {path:'analystnav',component:AnalystnavComponent, canActivate: [AuthGuard]},
  {path:'manager-home',component:ManagerHomeComponent, canActivate: [AuthGuard]},
  {path:'analyst-home',component:AnalystHomeComponent, canActivate: [AuthGuard]},
  {path:'error',component:ErrorComponent, canActivate: [AuthGuard]},
  {path: 'manager-add-project', component: ManagerAddProjectComponent, canActivate: [AuthGuard]},
  {path:'admin/view/feedback',component:ManagerviewfeedbackComponent, canActivate: [AuthGuard]},
  {path:'analystaddfeedback', component:AnalystaddfeedbackComponent, canActivate: [AuthGuard] },
  {path:'analystviewfeedback', component:AnalystViewFeedbackComponent, canActivate: [AuthGuard]},
  { path: 'manager-view-project', component: ManagerViewProjectComponent },
  { path: 'view-project', component: ManagerViewProjectComponent },
  { path: 'manager-edit-project/:id', component: ManagerEditProjectComponent },
  { path: 'manager-view-requirement', component: ManagerViewRequirementComponent },
  {path:'analyst-add-requirement', component:AnalystAddRequirementComponent, canActivate: [AuthGuard]},
  {path:'analyst-view-requirement', component:AnalystViewRequirementComponent, canActivate: [AuthGuard]},
  {path:'analyst-view-project',component:AnalystViewProjectComponent,canActivate: [AuthGuard]},
  {path:'managerviewfeedback',component:ManagerviewfeedbackComponent,canActivate: [AuthGuard]},

  ];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
