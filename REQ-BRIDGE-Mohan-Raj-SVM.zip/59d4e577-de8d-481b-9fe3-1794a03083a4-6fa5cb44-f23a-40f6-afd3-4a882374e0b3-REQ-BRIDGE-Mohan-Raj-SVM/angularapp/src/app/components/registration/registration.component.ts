import { Component } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { User } from 'src/app/models/user.model';
import { AuthService } from 'src/app/services/auth.service';
import Swal from 'sweetalert2';
 
@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent {
  confirmPassword: string = '';
 
  userExists = false;
  user: User = {
    Email: '',
    Password: '',
    Username: '',
    MobileNumber: '',
    UserRole: ''
  };
 
  constructor(private router: Router, private AuthService: AuthService) { }
 
  onSubmit(form: NgForm) {
    if (form.invalid) {
      Swal.fire({
        icon: 'error',
        title: 'Oops...',
        text: 'All fields are required!',
      });
      return;
    }
 
    this.AuthService.register(this.user).subscribe(
      (res) => {
        // Simulate user existence check
        if (this.user.Email === 'existing@example.com') {
          this.userExists = true;
          Swal.fire({
            icon: 'error',
            title: 'Oops...',
            text: 'User already exists!',
          });
          return;
        }
        this.userExists = false;
        Swal.fire({
          icon: 'success',
          title: 'Success',
          text: 'Registration successful!',
        }).then(() => {
          // Navigate to login page on successful registration
          this.router.navigate(['/login']);
        });
      },
      (error) => {
        Swal.fire({
          icon: 'error',
          title: 'Oops...',
          text: 'An error occurred during registration!',
        });
      }
    );
  }
}