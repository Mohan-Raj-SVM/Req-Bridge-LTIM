import { Component, OnInit } from '@angular/core';
import Swal from 'sweetalert2';
import { Router } from '@angular/router';

@Component({
  selector: 'app-analystnav',
  templateUrl: './analystnav.component.html',
  styleUrls: ['./analystnav.component.css']
})
export class AnalystnavComponent implements OnInit {

  constructor(private router: Router) { }

  ngOnInit(): void {
  }

  confirmLogout(): void {
    Swal.fire({
      title: 'Are you sure?',
      text: 'Do you want to logout?',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Yes, Logout',
      confirmButtonColor: '#ff4d4d', // Softer red for the confirm button
      cancelButtonText: 'Cancel'
    }).then((result) => {
      if (result.isConfirmed) {
        // Perform logout logic here, e.g., clearing local storage
        localStorage.clear();
        Swal.fire({
          title: 'Logged out successfully!',
          icon: 'success',
          confirmButtonText: 'OK'
        }).then(() => {
          this.router.navigate(['/login']);
        });
      }
    });
  }
}
