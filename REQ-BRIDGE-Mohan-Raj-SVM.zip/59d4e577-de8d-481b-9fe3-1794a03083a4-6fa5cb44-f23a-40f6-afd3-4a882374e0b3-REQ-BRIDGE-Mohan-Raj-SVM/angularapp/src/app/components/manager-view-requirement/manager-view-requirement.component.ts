import { Component } from '@angular/core';

@Component({
  selector: 'app-manager-view-requirement',
  templateUrl: './manager-view-requirement.component.html',
  styleUrls: ['./manager-view-requirement.component.css']
})
export class ManagerViewRequirementComponent {
  requirements = [
    { title: 'Requirement 1', description: 'Description 1', status: 'Pending' },
    { title: 'Requirement 2', description: 'Description 2', status: 'Pending' }
  ];

  updateStatus(requirement: any, status: string) {
    requirement.status = status;
  }
}
