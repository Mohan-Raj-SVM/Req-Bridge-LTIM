import { Component, OnInit } from '@angular/core';
import { FeedbackService } from 'src/app/services/feedback.service';
import { Feedback } from 'src/app/models/feedback.model';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-analystviewfeedback',
  templateUrl: './analystviewfeedback.component.html',
  styleUrls: ['./analystviewfeedback.component.css']
})
export class AnalystViewFeedbackComponent implements OnInit {
  feedbacks: Feedback[] = [];

  constructor(private feedbackService: FeedbackService) { }

  ngOnInit(): void {
    this.loadFeedbacks();

  }

  loadFeedbacks(): void {
    const userId = localStorage.getItem("userId");
    if (userId) {
      this.feedbackService.getAllFeedbacksByUserId(userId).subscribe(
        (data: Feedback[]) => {
          this.feedbacks = data;
        },
        error => {
          console.error('Error fetching feedbacks', error);
        }
      );
    } else {
      console.error('User ID not found in local storage');
    }
  }

  deleteFeedback(feedbackId: number): void {
  Swal.fire({
    title: 'Are you sure?',
    text: 'Do you want to delete this feedback?',
    icon: 'warning',
    showCancelButton: true,
    confirmButtonText: 'Yes, Delete',
    confirmButtonColor: '#ff4d4d', // Softer red for the confirm button
    cancelButtonText: 'Cancel'
  }).then((result) => {
    if (result.isConfirmed) {
      this.feedbackService.deleteFeedback(feedbackId.toString()).subscribe(
        () => {
          Swal.fire('Deleted!', 'Feedback has been deleted.', 'success');
          this.feedbacks = this.feedbacks.filter(feedback => feedback.FeedbackId !== feedbackId); // Remove the deleted feedback from the array
        },
        error => {
          console.error('Error deleting feedback', error);
          Swal.fire('Error!', 'There was a problem deleting the feedback.', 'error');
        }
      );
    }
  });
}

}
