import { Component, OnInit } from '@angular/core';
import { ProjectService } from 'src/app/services/project.service';

@Component({
  selector: 'app-analyst-view-project',
  templateUrl: './analyst-view-project.component.html',
  styleUrls: ['./analyst-view-project.component.css']
})
export class AnalystViewProjectComponent implements OnInit {
  projects: any[] = [];

  constructor(private projectService: ProjectService) { }

  ngOnInit(): void {
    this.getProjects();
  }

  getProjects(): void {
    this.projectService.getAllProjects().subscribe((data: any[]) => {
      this.projects = data;
    });
  }
}
