import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ProjectRequirementService } from 'src/app/services/project-requirement.service';
import { ActivatedRoute, Router } from '@angular/router';
import { ProjectRequirement } from 'src/app/models/projectRequirement.model';
 
@Component({
  selector: 'app-analyst-add-requirement',
  templateUrl: './analyst-add-requirement.component.html',
  styleUrls: ['./analyst-add-requirement.component.css']
})
export class AnalystAddRequirementComponent implements OnInit {
 
  requirementId: number | null = null;
 
  constructor(
    private projectRequirementService: ProjectRequirementService,
    private router: Router,
    private route: ActivatedRoute
  ) { }
 
  checkTitle: string = "Add Requirement";
  isUserDialogOpen: boolean = false;
  messageValue: string = "Added";
 
  requirement: ProjectRequirement = {
    RequirementTitle: '',
    RequirementDescription: '',
    UserId: 1, // Set this to a valid UserId that exists in the Users table
    Status: '' // This can be set dynamically if needed
  };
 
  ngOnInit(): void {
    this.route.paramMap.subscribe((params) => {
      this.requirementId = +params.get('id');
      if (this.requirementId) {
        this.loadRequirement(this.requirementId);
      }
    });
  }
 
  loadRequirement(id: number): void {
    this.projectRequirementService.getProjectRequirementById(id).subscribe(
      (requirement) => {
        this.requirement = requirement;
      },
      (error) => {
        console.error('Error loading requirement:', error);
        this.handleError(error);
      }
    );
  }
 
  onAddSubmit(form: NgForm) {
    if (form.valid) {
      console.log('Form is valid, attempting to add requirement:', this.requirement);
      console.log('UserId being used:', this.requirement.UserId);
      this.projectRequirementService.addProjectRequirement(this.requirement).subscribe(
        result => {
          console.log('Requirement added successfully:', result);
          this.messageValue = "Requirement added successfully!";
          this.openUserDialog();
          form.resetForm();
        },
        error => {
          console.error('Error adding requirement:', error);
          this.handleError(error);
        }
      );
    } else {
      console.log('Form is invalid:', form);
      this.messageValue = "All fields are required";
      this.openUserDialog();
    }
  }
 
  handleError(error: any) {
    if (error.status === 409) {
      this.messageValue = "Requirement with the same title already exists";
    } else {
      this.messageValue = `An error occurred while adding the requirement: ${error.message}`;
    }
    this.openUserDialog();
  }
 
  openUserDialog(): void {
    this.isUserDialogOpen = true;
  }
 
  closeUserDialog(): void {
    this.isUserDialogOpen = false;
    this.router.navigate(['/analyst-view-requirement']);
  }
 
  close(): void {
    this.router.navigate(['/analyst-view-requirement']);
  }
}