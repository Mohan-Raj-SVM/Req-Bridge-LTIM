import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ProjectService } from 'src/app/services/project.service';
import { Project } from 'src/app/models/project.model';
import Swal from 'sweetalert2';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-manager-edit-project',
  templateUrl: './manager-edit-project.component.html',
  styleUrls: ['./manager-edit-project.component.css']
})
export class ManagerEditProjectComponent implements OnInit {
  project: Project = {
    ProjectId: 0, 
    ProjectTitle: '',
    ProjectDescription: '',
    StartDate: '',
    EndDate: '',
    FrontEndTechStack: '',
    BackendTechStack: '',
    Database: '',
    Status: ''
  };

  checkTitle: string = "Edit Project";
  projectId: number;

  constructor(
    private projectService: ProjectService,
    private route: ActivatedRoute,
    private router: Router,
  ) { }

  ngOnInit(): void {
    this.route.params.subscribe(params => {
      this.projectId = +params['id'];
      alert(this.projectId);
      if (this.projectId) {
        this.getProjectById(this.projectId);
      }
    });
  }

  getProjectById(id: number): void {
    this.projectService.getProjectById(id).subscribe(
      (res: any) => {
        this.project = res.project;
        this.project.StartDate = this.formatDate(this.project.StartDate);
        this.project.EndDate = this.formatDate(this.project.EndDate);
        console.log(res);
      },
      (error) => console.error('Error fetching project', error)
    );
  }

  formatDate(dateString: string): string {
    const date = new Date(dateString);
    const year = date.getFullYear();
    const month = ('0' + (date.getMonth() + 1)).slice(-2);
    const day = ('0' + date.getDate()).slice(-2);
    return `${year}-${month}-${day}`;
  }

  onEditSubmit(form: NgForm): void {
    if (form.valid) {
      this.projectService.updateProject(this.project.ProjectId, this.project).subscribe(
        result => {
          Swal.fire({
            title: 'Success!',
            text: 'Project updated successfully!',
            icon: 'success',
            confirmButtonText: 'OK'
          }).then(() => {
            this.router.navigate(['/view-project']);
          });
        },
        error => {
          console.error('Error updating project', error);
          Swal.fire({
            title: 'Error!',
            text: 'There was an error updating the project.',
            icon: 'error',
            confirmButtonText: 'OK'
          });
        }
      );
    } else {
      Swal.fire({
        title: 'Error!',
        text: 'All fields are required',
        icon: 'error',
        confirmButtonText: 'OK'
      });
    }
  }
}
