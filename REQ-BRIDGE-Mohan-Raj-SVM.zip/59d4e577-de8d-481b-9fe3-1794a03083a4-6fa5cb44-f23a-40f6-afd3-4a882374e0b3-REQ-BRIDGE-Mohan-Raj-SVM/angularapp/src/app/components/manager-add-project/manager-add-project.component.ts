
import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ProjectService } from 'src/app/services/project.service';
import { Router } from '@angular/router';
import { Project } from 'src/app/models/project.model';
import Swal from 'sweetalert2'; // Import SweetAlert2
@Component({
  selector: 'app-manager-add-project',
  templateUrl: './manager-add-project.component.html',
  styleUrls: ['./manager-add-project.component.css']
})

export class ManagerAddProjectComponent implements OnInit {

  constructor(private projectService: ProjectService, private router: Router) { }

  checkTitle: string = "Create New Project";
  isUserDialogOpen: boolean = false;
  messageValue: string = "Added";

  ngOnInit(): void {
  }

  project: Project = {
    ProjectTitle: '',
    ProjectDescription: '',
    StartDate: '',
    EndDate: '',
    FrontEndTechStack: '',
    BackendTechStack: '',
    Database: '',
    Status: '',
    ProjectId: 0
  };

  onAddSubmit(form: NgForm) {
    if (form.valid) {
      this.projectService.addProject(this.project).subscribe(
        result => {
          Swal.fire({ // SweetAlert for success
            title: 'Success!',
            text: 'Project added successfully!',
            icon: 'success',
            confirmButtonText: 'OK'
          }).then(() => {
            form.resetForm();
            this.router.navigate(['/view-project']);
          });
        },
        error => {
          if (error.status === 409) {
            Swal.fire({ // SweetAlert for conflict error
              title: 'Error!',
              text: 'Project with the same title already exists',
              icon: 'error',
              confirmButtonText: 'OK'
            });
          }
        }
      );
    } else {
      Swal.fire({ // SweetAlert for form validation error
        title: 'Error!',
        text: 'All fields are required',
        icon: 'error',
        confirmButtonText: 'OK'
      });
    }
  }

  openUserDialog(): void {
    this.isUserDialogOpen = true;
  }

  closeUserDialog(): void {
    this.isUserDialogOpen = false;
    this.router.navigate(['/view-project']);
  }

  close(): void {
    this.router.navigate(['/view-project']);
  }
}
