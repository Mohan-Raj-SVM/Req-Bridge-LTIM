import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FeedbackService } from 'src/app/services/feedback.service';
import { Feedback } from 'src/app/models/feedback.model';
import Swal from'sweetalert2';
import { User } from 'src/app/models/user.model';
 
@Component({
  selector: 'app-managerviewfeedback',
  templateUrl: './managerviewfeedback.component.html',
  styleUrls: ['./managerviewfeedback.component.css']
})
export class ManagerviewfeedbackComponent implements OnInit {
  feedbacks: Feedback[] =[];
  isProfileVisible: boolean = false;
  isLogoutConfirmVisible: boolean = false;
  profileUserId: number | null = null;
  selectedUser:any= null;
 
  constructor(private feedbackService: FeedbackService, private router: Router) {}
 
  ngOnInit(): void {
    this.loadFeedbacks();
  }
 
  // Load all feedbacks
  loadFeedbacks(): void {
    this.feedbackService.getFeedbacks().subscribe((data: any) => {
      this.feedbacks = data;
      if (!this.feedbacks.length) {
        Swal.fire('Oops!', 'No records found.', 'info');
      }
    });
  }
 
 name:string=localStorage.getItem('userName')
  // Show user profile in a modal
  showProfile(user: User): void {
    Swal.fire({
      title: 'User Information',
      html: `<p><strong>Email:</strong> ${user.Email}</p>
      <p><strong>Username:</strong> ${user.Username}</p>
      <p><strong>Mobile Number:</strong> ${user.MobileNumber}</p>`,
      icon: 'info',
      confirmButtonText: 'OK'
    });
  }
 
  closeProfile() {
    this.isProfileVisible = false;
    this.profileUserId = null;
  }
 
  confirmLogout() {
    this.isLogoutConfirmVisible = true;
  }
 
  closeLogoutConfirm() {
    this.isLogoutConfirmVisible = false;
  }
 
  logout() {
    // Add your logout logic here
    this.router.navigate(['/login']);
  }
 
}