
// import { Component, OnInit } from '@angular/core';
// import { Feedback } from 'src/app/models/feedback.model';
// import { FeedbackService } from 'src/app/services/feedback.service';

// @Component({
//   selector: 'app-analystaddfeedback',
//   templateUrl: './analystaddfeedback.component.html',
//   styleUrls: ['./analystaddfeedback.component.css']
// })
// export class AnalystaddfeedbackComponent implements OnInit {
//   feedback: Feedback = new Feedback();
//   feedbackMessage: string = '';

//   constructor(private feedbackService: FeedbackService) { }

//   ngOnInit(): void {
//   }

//   onSubmit(): void {
//     if (!this.feedback.FeedbackText) {
//       this.feedbackMessage = 'Feedback is required';
//       return;
//     }

//     this.feedback.Date = new Date(); // Set the current date

//     console.log('Submitting feedback:', this.feedback); // Log the feedback payload

//     this.feedbackService.sendFeedback(this.feedback).subscribe(
//       response => {
//         alert('Successfully Added!');
//         this.feedback = new Feedback(); // Reset the form
//       },
//       error => {
//         console.error('Error adding feedback', error);
//         alert('There was a problem with the server. Please try again later.');
//       }
//     );
//   }
// }

import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Feedback } from 'src/app/models/feedback.model';
import { FeedbackService } from 'src/app/services/feedback.service';
import Swal from 'sweetalert2';

@Component({
   selector: 'app-analystaddfeedback',
   templateUrl: './analystaddfeedback.component.html',
   styleUrls: ['./analystaddfeedback.component.css']
})
export class AnalystaddfeedbackComponent implements OnInit {

  feedback: Feedback = {
    FeedbackId: 0,
    UserId: 0,
    FeedbackText: "",
    Date: new Date()
  };
  feedbackMessage: string = '';

  constructor(private feedbackService: FeedbackService, private router: Router) { }

  ngOnInit(): void {
  }

  addFeedback() {
    if (!this.feedback.FeedbackText) {
      this.feedbackMessage = 'Feedback is required';
      return;
    } 

    this.feedback.UserId = +localStorage.getItem("userId");
    this.feedback.Date = new Date();

    console.log('Submitting feedback:', this.feedback); // Log the feedback payload

    this.feedbackService.sendFeedback(this.feedback).subscribe(
      res => {
        console.log(res);
        Swal.fire({
          title: 'Success!',
          text: 'Feedback added successfully.',
          icon: 'success',
          confirmButtonText: 'OK'
        }).then(() => {
          this.router.navigate(['/analystviewfeedback']);
        });
      },
      error => {
        console.error('Error adding feedback', error);
        Swal.fire({
          title: 'Error!',
          text: 'There was a problem with the server. Please try again later.',
          icon: 'error',
          confirmButtonText: 'OK'
        });
      }
    );
  }
}


