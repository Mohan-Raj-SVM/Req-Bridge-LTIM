import { Component, OnInit } from '@angular/core';
import { ProjectService } from 'src/app/services/project.service';
import { Project } from 'src/app/models/project.model';
import Swal from 'sweetalert2';
import { Router } from '@angular/router';

@Component({
  selector: 'app-manager-view-project',
  templateUrl: './manager-view-project.component.html',
  styleUrls: ['./manager-view-project.component.css']
})
export class ManagerViewProjectComponent implements OnInit {
  projects: Project[] = [];
  filteredProjects: Project[] = [];
  searchTitle: string = '';
  showDeleteModal: boolean = false; // Controls modal visibility
  confirmedDeleteId: number | null = null; // Stores the ID to be deleted upon confirmation

  constructor(private projectService: ProjectService, private router: Router) { }

  ngOnInit(): void {
    this.getProjects();
  }

  getProjects(): void {
    this.projectService.getAllProjects().subscribe(
      (data: Project[]) => {
        if (Array.isArray(data)) {
          this.projects = data;
          this.filteredProjects = data;
        } else {
          console.error('Data is not an array', data);
        }
      },
      error => {
        console.error('Error fetching projects', error);
      }
    );
  }

  searchProjects(): void {
    if (this.searchTitle.trim() === '') {
      this.filteredProjects = [...this.projects]; // Show all projects if search query is empty
    } else {
      this.filteredProjects = this.projects.filter(project =>
        project.ProjectTitle.toLowerCase().startsWith(this.searchTitle.toLowerCase())
      );
    }
  }

  confirmDelete(projectId: number): void {
    document.body.classList.add('blur');
    Swal.fire({
      title: 'Are you sure?',
      text: "You won't be able to revert this!",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#d33',
      cancelButtonColor: '#3085d6',
      confirmButtonText: 'Yes, delete it!'
    }).then((result) => {
      if (result.isConfirmed) {
        this.deleteProject(projectId); // Call deleteProject with the projectId
      }
    });
  }

  deleteProject(projectId: number): void {
    this.projectService.deleteProject(projectId).subscribe(
      () => {
        this.getProjects(); // Refresh the project list after deletion
        Swal.fire(
          'Deleted!',
          'Your project has been deleted.',
          'success'
        );
      },
      error => {
        console.error('Error deleting project', error);
        Swal.fire(
          'Error!',
          'There was an error deleting your project.',
          'error'
        );
      }
    );
  }

  cancelDelete(): void {
    this.closeDeleteModal();
  }

  private closeDeleteModal(): void {
    this.showDeleteModal = false;
    this.confirmedDeleteId = null;
  }

  editProject(ProjectId: number): void {
    this.router.navigate([`/manager-edit-project/${ProjectId}`]);
  }
}
