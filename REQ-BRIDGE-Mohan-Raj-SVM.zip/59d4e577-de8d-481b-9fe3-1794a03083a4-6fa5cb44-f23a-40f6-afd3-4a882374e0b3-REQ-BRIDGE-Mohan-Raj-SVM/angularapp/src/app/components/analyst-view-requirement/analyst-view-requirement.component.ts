import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ProjectRequirementService } from 'src/app/services/project-requirement.service';
 
@Component({
  selector: 'app-analyst-view-requirement',
  templateUrl: './analyst-view-requirement.component.html',
  styleUrls: ['./analyst-view-requirement.component.css']
})
export class AnalystViewRequirementComponent implements OnInit {
 
  requirements = [];
  projectRequirementId = 0;
 
  showModal = false;
  requirementToDelete = null;
 
  constructor(
    private projectRequirementService: ProjectRequirementService,
    private router: Router,
    private route: ActivatedRoute
  ) { }
 
 
  ngOnInit(): void {
    this.route.paramMap.subscribe((data) => {
      this.projectRequirementId = +data.get('id');
      this.loadRequirements();
    })
  }
 
  loadRequirements() {
    this.projectRequirementService.getAllProjectRequirements().subscribe((data: any) => {
      this.requirements = data;
      console.log(this.requirements);
    })
  }
 
  confirmDelete(requirement) {
    this.requirementToDelete = requirement;
    this.showModal = true;
  }
 
  closeModal() {
    this.showModal = false;
    this.requirementToDelete = null;
  }
 
  deleteRequirement() {
    if (this.requirementToDelete) {
      this.requirements = this.requirements.filter(r => r.id !== this.requirementToDelete.id);
      this.closeModal();
    }
  }
}