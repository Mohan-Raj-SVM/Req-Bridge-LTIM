import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AnalystHomeComponent } from './analyst-home.component';

describe('AnalystHomeComponent', () => {
  let component: AnalystHomeComponent;
  let fixture: ComponentFixture<AnalystHomeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AnalystHomeComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AnalystHomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
