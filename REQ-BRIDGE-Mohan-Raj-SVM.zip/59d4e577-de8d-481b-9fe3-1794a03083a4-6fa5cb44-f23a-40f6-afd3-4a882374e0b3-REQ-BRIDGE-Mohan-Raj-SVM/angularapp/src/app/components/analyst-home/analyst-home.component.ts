import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-analyst-home',
  templateUrl: './analyst-home.component.html',
  styleUrls: ['./analyst-home.component.css']
})
export class AnalystHomeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
