import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { Project } from '../models/project.model';

@Injectable({
  providedIn: 'root'
})
export class ProjectService {
  private apiUrl = 'https://8080-efdfefdceeeefaeaedaceeffacbfafafdaeb.premiumproject.examly.io';

  constructor(private http: HttpClient) {}

  getAllProjects(): Observable<Project[]> {
    return this.http.get<{ projects: Project[] }>(this.apiUrl + "/api/projects").pipe(
      map(response => response.projects)
    );
  }

  getProjectById(projectId: number): Observable<Project> {
    return this.http.get<Project>(`${this.apiUrl}/api/projects/${projectId}`);
  }

  addProject(project: Project): Observable<any> {
    return this.http.post<Project>(`${this.apiUrl}/api/projects`, project);
  }

  updateProject(projectId: number, project: Project): Observable<any> {
    return this.http.put<Project>(`${this.apiUrl}/api/projects/${projectId}`, project);
  }

  deleteProject(projectId: number): Observable<any> {
    return this.http.delete<void>(`${this.apiUrl}/api/projects/${projectId}`);
  }
}
