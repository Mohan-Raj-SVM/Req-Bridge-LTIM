import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ProjectRequirement } from '../models/projectRequirement.model';

@Injectable({
  providedIn: 'root'
})
export class ProjectRequirementService {
  public apiUrl='https://8080-efdfefdceeeefaeaedaceeffacbfafafdaeb.premiumproject.examly.io';
  constructor(private http:HttpClient) { }
  
  getAllProjectRequirements():Observable<ProjectRequirement[]>
  {
    return this.http.get<ProjectRequirement[]>(`${this.apiUrl}/api/ProjectRequirement`);
  }
  getProjectRequirementById(requirementId:number):Observable<ProjectRequirement>
  {
    return this.http.get<ProjectRequirement>(`${this.apiUrl}/api/ProjectRequirement/${requirementId}`);
  }
  addProjectRequirement(projectRequirement:ProjectRequirement):Observable<any>
  {
    return this.http.post<ProjectRequirement>(`${this.apiUrl}/api/ProjectRequirement`,projectRequirement);
  }
  updateProjectRequirement(requirementId:number,projectRequirement:ProjectRequirement):Observable<any>
  {
    return this.http.put<any>(`${this.apiUrl}/api/ProjectRequirement/${requirementId}`,projectRequirement);
  }
  deleteProjectRequirement(requirementId:number):Observable<any>
  {
    return this.http.delete<any>(`${this.apiUrl}/api/ProjectRequirement/${requirementId}`);
  }
}
