import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Feedback } from '../models/feedback.model';
@Injectable({
  providedIn: 'root'
})
export class FeedbackService {
  public apiUrl:string='https://8080-efdfefdceeeefaeaedaceeffacbfafafdaeb.premiumproject.examly.io';
  constructor(private http:HttpClient) { }

  sendFeedback(feedback:Feedback):Observable<any>
  {
    return this.http.post<any>(`${this.apiUrl}/api/feedback`,feedback);
  }

  getAllFeedbacksByUserId(userId:string):Observable<Feedback[]>
  {
    return this.http.get<Feedback[]>(`${this.apiUrl}/api/feedback/user/${userId}`);
  }
  deleteFeedback(feedbackId:string):Observable<any>
  {
    return this.http.delete<any>(`${this.apiUrl}/api/feedback/${feedbackId}`);
  }
  getFeedbacks():Observable<Feedback[]>
  {
    return this.http.get<Feedback[]>(`${this.apiUrl}/api/feedback`);
  }
}
