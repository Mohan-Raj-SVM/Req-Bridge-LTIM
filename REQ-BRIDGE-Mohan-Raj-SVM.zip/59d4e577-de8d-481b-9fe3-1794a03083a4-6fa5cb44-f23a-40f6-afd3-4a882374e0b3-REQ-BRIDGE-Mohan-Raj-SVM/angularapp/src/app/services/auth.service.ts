import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { User } from '../models/user.model';
import { Observable } from 'rxjs';
import { Login } from '../models/login.model';
 
@Injectable({
  providedIn: 'root'
})
export class AuthService {
 
  public apiUrl='https://8080-efdfefdceeeefaeaedaceeffacbfafafdaeb.premiumproject.examly.io';
 
  constructor(private http:HttpClient) { }
 
  register(user:User):Observable<any>
  {
    console.log(user);
    return this.http.post<any>(`${this.apiUrl}/api/register`,user);
  }
 
  login(login:Login):Observable<any>
  {
   
    return this.http.post(`${this.apiUrl}/api/login`,login);
  }
 
  isRole()
  {
    const token=localStorage.getItem("Token").split('.');
    let payload=JSON.parse(atob(token[1]));
    localStorage.setItem('userRole',payload['http://schemas.microsoft.com/ws/2008/06/identity/claims/role']);
    localStorage.setItem('userName',payload['http://schemas.xmlsoap.org/ws/2005/05/identity/claims/name']);
    localStorage.setItem('userId',payload['http://schemas.xmlsoap.org/ws/2005/05/identity/claims/nameidentifier']);
  }
 
  isLoggedIn()
  {
    if(localStorage.getItem('userRole')==="Project Manager" || localStorage.getItem('userRole')==="Requirement Analyst")
    {
      return true;
    }
    return false;
  }
 
  isAdmin()
  {
    return localStorage.getItem('userRole')==="Project Manager";
  }
 
  isUser()
  {
    return localStorage.getItem('userRole')==="Requirement Analyst";
  }
 
  logout()
  {
    localStorage.clear();
  }
}