import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import {HTTP_INTERCEPTORS, HttpClientModule} from '@angular/common/http';
import { HomeComponent } from './components/home/home.component';
import { AnalystAddRequirementComponent } from './components/analyst-add-requirement/analyst-add-requirement.component';
import { AnalystViewProjectComponent } from './components/analyst-view-project/analyst-view-project.component';
import { AnalystViewRequirementComponent } from './components/analyst-view-requirement/analyst-view-requirement.component';
import { AnalystaddfeedbackComponent } from './components/analystaddfeedback/analystaddfeedback.component';
import { AnalystnavComponent } from './components/analystnav/analystnav.component';
//import { AnalystviewfeedbackComponent } from './components/analystviewfeedback/analystviewfeedback.component';
import { ErrorComponent } from './components/error/error.component';
import { LoginComponent } from './components/login/login.component';
import { ManagerAddProjectComponent } from './components/manager-add-project/manager-add-project.component';
import { ManagerEditProjectComponent } from './components/manager-edit-project/manager-edit-project.component';
import { ManagerViewProjectComponent } from './components/manager-view-project/manager-view-project.component';
import { ManagerViewRequirementComponent } from './components/manager-view-requirement/manager-view-requirement.component';
import { ManagernavComponent } from './components/managernav/managernav.component';
import { ManagerviewfeedbackComponent } from './components/managerviewfeedback/managerviewfeedback.component';
import { NavbarComponent } from './components/navbar/navbar.component';
import { RegistrationComponent } from './components/registration/registration.component';
import { FormsModule } from '@angular/forms';
import { ManagerHomeComponent } from './components/manager-home/manager-home.component';
import { AnalystHomeComponent } from './components/analyst-home/analyst-home.component';
import { AuthInterceptor } from './services/auth.interceptor';
import { AnalystViewFeedbackComponent } from './components/analystviewfeedback/analystviewfeedback.component';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    AnalystAddRequirementComponent,
    AnalystViewProjectComponent,
    AnalystViewRequirementComponent,
    AnalystaddfeedbackComponent,
    AnalystnavComponent,
    //AnalystviewfeedbackComponent,
    ErrorComponent,
    LoginComponent,
    ManagerAddProjectComponent,
    ManagerEditProjectComponent,
    ManagerViewProjectComponent,
    ManagerViewRequirementComponent,
    ManagernavComponent,
    ManagerviewfeedbackComponent,
    NavbarComponent,
    RegistrationComponent,
    ManagerHomeComponent,
    AnalystHomeComponent,
    AnalystViewFeedbackComponent

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [
    {
      provide: HTTP_INTERCEPTORS,
      useClass: AuthInterceptor,
      multi: true
    }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
