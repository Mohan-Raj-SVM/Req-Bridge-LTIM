export interface ProjectRequirement
{
    RequirementId?: number;

    UserId: number;
    
    RequirementTitle: string;
    
    RequirementDescription: string;
    
    Status: string;
}