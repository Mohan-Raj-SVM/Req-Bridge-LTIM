using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using dotnetapp.Models;
using dotnetapp.Data;
using dotnetapp.Exceptions;
using Microsoft.EntityFrameworkCore;

namespace dotnetapp.Services
{
    public class ProjectService
    {
        private readonly ApplicationDbContext _context;

        public ProjectService(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<Project>> GetAllProjects()
        {
            IEnumerable<Project> list = await _context.Projects.ToListAsync();
            return list;
        }

        public async Task<Project> GetProjectById(int projectId)
        {
            Project project = await _context.Projects.FindAsync(projectId);
            if (project != null)
            {
                return project;
            }
            return null;
        }

        public async Task<bool> AddProject(Project project)
        {
            var existingProject = await _context.Projects
                .FirstOrDefaultAsync(p => p.ProjectTitle == project.ProjectTitle);
            if (existingProject != null)
            {
                throw new ProjectException("Project with the same title already exists");
            }

            await _context.Projects.AddAsync(project);
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<bool> UpdateProject(int projectId, Project project)
        {
            var oldProject = await _context.Projects.FindAsync(projectId);
            if (oldProject == null)
            {
                return false;
            }

            // Update only the modifiable properties
            oldProject.ProjectTitle = project.ProjectTitle;
            oldProject.ProjectDescription = project.ProjectDescription;
            oldProject.StartDate = project.StartDate;
            oldProject.EndDate = project.EndDate;
            oldProject.FrontEndTechStack = project.FrontEndTechStack;
            oldProject.BackendTechStack = project.BackendTechStack;
            oldProject.Database = project.Database;
            oldProject.Status = project.Status;

            _context.Entry(oldProject).State = EntityState.Modified;
            await _context.SaveChangesAsync();
            return true;
        }


        public async Task<bool> DeleteProject(int projectId)
        {
            Project project = await _context.Projects.FindAsync(projectId);
            if (project != null)
            {
                _context.Projects.Remove(project);
                await _context.SaveChangesAsync();
                return true;
            }
            return false;
        }
    }
}
