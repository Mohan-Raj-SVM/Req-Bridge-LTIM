using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using dotnetapp.Data;
using dotnetapp.Models;
using dotnetapp.Exceptions;
using dotnetapp.Services;
 
namespace dotnetapp.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ProjectRequirementController : ControllerBase
    {
        private readonly ProjectRequirementService _service;
 
        public ProjectRequirementController(ProjectRequirementService service)
        {
            _service = service;
        }
 
        [HttpGet]
        public async Task<ActionResult<IEnumerable<ProjectRequirement>>> GetAllProjectRequirements()
        {
            try
            {
                var projectRequirements = await _service.GetAllProjectRequirements();
                return Ok(projectRequirements);
            }
            catch (Exception ex)
            {
                return Ok($"An error occurred: {ex.Message}");
            }
        }
 
        [HttpGet("{requirementId}")]
        public async Task<ActionResult<ProjectRequirement>> GetProjectRequirementById(int requirementId)
        {
            try
            {
                var projectRequirement = await _service.GetProjectRequirementById(requirementId);
                if (projectRequirement == null)
                {
                    return Ok("Project requirement not found");
                }
                return Ok(projectRequirement);
            }
            catch (Exception ex)
            {
                return Ok($"An error occurred: {ex.Message}");
            }
        }
 
        [HttpGet("user/{userId}")]
        public async Task<ActionResult<IEnumerable<ProjectRequirement>>> GetProjectRequirementsByUserId(int userId)
        {
            try
            {
                var projectRequirements = await _service.GetProjectRequirementsByUserId(userId);
                if (projectRequirements == null)
                {
                    return Ok("No project requirements found for this user");
                }
                return Ok(projectRequirements);
            }
            catch (Exception ex)
            {
                return Ok($"An error occurred: {ex.Message}");
            }
        }
 
        [HttpPost]
        public async Task<ActionResult> AddProjectRequirement([FromBody] ProjectRequirement projectRequirement)
        {
            try
            {
                await _service.AddProjectRequirement(projectRequirement);
                return Ok(new {message = "Project requirement added successfully"});
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal Server Error: {ex.Message}");
            }
        }
 
        [HttpPut("{requirementId}")]
        public async Task<ActionResult> UpdateProjectRequirement(int requirementId, [FromBody] ProjectRequirement projectRequirement)
        {
            if (requirementId != projectRequirement.RequirementId)
            {
                return BadRequest("Requirement ID mismatch");
            }
 
            try
            {
                var result = await _service.UpdateProjectRequirement(requirementId, projectRequirement);
                if (!result)
                {
                    return NotFound("Project requirement not found");
                }
                return Ok("Project requirement updated successfully");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal Server Error: {ex.Message}");
            }
        }
 
        [HttpDelete("{requirementId}")]
        public async Task<ActionResult> DeleteProjectRequirement(int requirementId)
        {
            try
            {
                var result = await _service.DeleteProjectRequirement(requirementId);
                if (!result)
                {
                    return NotFound("Project requirement not found");
                }
                return Ok("Project requirement deleted successfully");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal Server Error : {ex.Message}");
            }
        }
 
    }
}