using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using dotnetapp.Models;
using dotnetapp.Services;
using dotnetapp.Exceptions;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;

namespace dotnetapp.Controllers
{
    [ApiController]
    [Route("api/")]
    public class ProjectController : ControllerBase
    {
        private readonly ProjectService _service;

        public ProjectController(ProjectService service)
        {
            _service = service;
        }

        [Authorize]
        [HttpGet("projects")]
        public async Task<ActionResult<IEnumerable<Project>>> GetAllProjects()
        {
            try
            {
                var projects = await _service.GetAllProjects();
                return Ok(new { projects = projects });
            }
            catch (Exception e)
            {
                return StatusCode(500, $"Internal server error {e.Message}");
            }
        }

        // [Authorize(Roles = "Admin, User")]
        [HttpGet("projects/{projectId}")]
        public async Task<ActionResult<Project>> GetProjectById(int projectId)
        {
            try
            {
                var project = await _service.GetProjectById(projectId);
                if (project == null)
                {
                    return NotFound(new { message = "Project not found" });
                }
                return Ok(new { project = project });
            }
            catch (Exception e)
            {
                return StatusCode(500, $"Internal server error {e.Message}");
            }
        }

        // [Authorize(Roles = "User")]
        [HttpPost("projects")]
        public async Task<ActionResult> AddProject([FromBody] Project project)
        {
            try
            {
                if (project == null)
                {
                    return BadRequest();
                }
                await _service.AddProject(project);
                return Ok(new { message = "Project added successfully" });
            }
            catch (ProjectException ex)
            {
                return BadRequest(new { message = ex.Message });
            }
            catch (Exception e)
            {
                return StatusCode(500, $"Internal server error {e.Message}");
            }
        }

        // [Authorize(Roles = "Admin, User")]
        [HttpPut("projects/{projectId}")]
        public async Task<ActionResult> UpdateProject(int projectId, [FromBody] Project project)
        {
            try
            {
                bool isUpdated = await _service.UpdateProject(projectId, project);
                if (isUpdated)
                {
                    return Ok(new { message = "Project updated successfully" });
                }
                else
                {
                    return NotFound(new { message = "Project not found" });
                }
            }
            catch (Exception e)
            {
                return StatusCode(500, $"Internal server error {e.Message}");
            }
        }

        // [Authorize(Roles = "User")]
        [HttpDelete("projects/{projectId}")]
        public async Task<ActionResult> DeleteProject(int projectId)
        {
            try
            {
                bool isDeleted = await _service.DeleteProject(projectId);
                if (isDeleted)
                {
                    return Ok(new { message = "Project deleted successfully" });
                }
                else
                {
                    return NotFound(new { message = "Project not found" });
                }
            }
            catch (Exception e)
            {
                return StatusCode(500, $"Internal server error {e.Message}");
            }
        }
    }
}
